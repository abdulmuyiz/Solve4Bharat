package com.example.realtime;

public class Variables {
    int request = 1;
    int frequency;
    //route;
    int number_of_buses;

    public Variables(){

    }


}
