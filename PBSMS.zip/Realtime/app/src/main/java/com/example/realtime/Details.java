package com.example.realtime;

public class Details {
    String name;
    String password;

    public Details(){

    }

    public Details(String name , String password){
        this.name = name;
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public String getPassword() {
        return password;
    }
}
