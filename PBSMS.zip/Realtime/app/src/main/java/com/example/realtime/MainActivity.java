package com.example.realtime;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {

    Button buttonAdd;

    DatabaseReference requestNumbers = FirebaseDatabase.getInstance().getReference();
    DatabaseReference req = requestNumbers.child("requests");
    DatabaseReference Results = FirebaseDatabase.getInstance().getReference("Solution");

    int no=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttonAdd =(Button) findViewById(R.id.buttonAddArtist);

        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Requests();
                req.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        int r = dataSnapshot.getValue(int.class);
                        r +=1;
                        no =r;

                        if(no>=50){
                            Results.setValue("Send " + no/50 +" Bus");
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
                req.setValue(no);
            }
        });
    }

    private void Requests(){
            Toast.makeText(this, "Request is sent", Toast.LENGTH_LONG).show();

    }
}
